import { createContext } from 'react';

const FirebaseContext = createContext();

export default FirebaseContext;
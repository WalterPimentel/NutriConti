import { createContext } from 'react';

const PedidoContext = createContext();

export default PedidoContext;
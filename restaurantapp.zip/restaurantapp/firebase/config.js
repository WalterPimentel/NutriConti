// AGREGA TUS CREDENCIALES AQUI

export default firebaseConfig;